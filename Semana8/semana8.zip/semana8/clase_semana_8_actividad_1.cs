﻿class clase_semana_8_actividad_1
{
    public static int CalcularFactorial(int numero)
    {
        if (numero == 0)
        {
            return 1;
        }
        else
        {
            int factorial = 1;
            for (int i = 1; i <= numero; i++)
            {
                factorial *= i;
            }
            return factorial;
        }
    }
    public static void Main()
    {
        Console.WriteLine("Ingrese un numero entero");
        int numero;
        do{

            if (int.TryParse(Console.ReadLine(), out numero) && numero >= 0)
            {
                int factorial = CalcularFactorial(numero);
                Console.WriteLine($"El factorial del numero {numero} es: {factorial}");
                break;
            }
            else
            {
                Console.WriteLine("Valor ingresado no valido");
                Console.WriteLine("Vuelva a ingresar un numero: ");
            }
        }while(true);

        
    }
}