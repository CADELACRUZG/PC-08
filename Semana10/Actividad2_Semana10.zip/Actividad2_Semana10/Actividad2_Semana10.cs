﻿class Actividad2_Semana10
{
    static void Main()
    {
        bool salida=false;
        int suma=0,p=0;
        int [] numeros = new int [8];
        for (int i=0;i<8;i++) //se realiza un contador para que se pida 8 veces un numero que sera asignado a una posicion del vector 
        {
            do
            {
                Console.Write("Ingrese un numero: ");
                if(int.TryParse(Console.ReadLine(), out int numero)) //se validan solo numeros enteros
                {
                    salida=true; //variable para la finalizacion del do while
                    Console.WriteLine($"en la posicion numero {i} "); //se indica la posicion del vector en la que se encuentra el numero ingresado
                    numeros [i] = numero; //se asigna el valor a una posicion del arreglo
                    suma+= numeros [i];  //se realiza la suma y asignacion de los numeros dentro del arreglo
                }      
                else
                {
                    Console.WriteLine("Valor ingresado no reconocido, se asignara un valor 0"); //en caso de no ingresar un entero mostrar mensaje
                    p++;
                    if(p>4)
                    {
                        Console.WriteLine("Demasiados intentos con valores no reconocidos, cerrando el programa...\n");
                        break;
                    }
                }  
            }while(salida==false);
        }
        Console.WriteLine("Valores ingresados:");
        foreach (int num in numeros)
        {
            Console.Write($"{num}" + " ");
        }
        Console.WriteLine($"\nLa suma de los numero es: {suma}");
        Console.WriteLine("El promedio de los numeros es: " + (suma/8));
    }
}
