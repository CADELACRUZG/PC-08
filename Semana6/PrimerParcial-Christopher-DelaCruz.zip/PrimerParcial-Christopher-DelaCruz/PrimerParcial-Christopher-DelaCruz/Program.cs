﻿class Parcial
{
    static void Main(string[]args)
    {
        int num1, num2, num3;

        Console.Write("Ingrese 3 números enteros");
        
        num1 = int.Parse(Console.ReadLine());
        num2 = int.Parse(Console.ReadLine());
        num3 = int.Parse(Console.ReadLine());

        if (num1 % 2 == 0) 
        {
            Console.WriteLine(num1 + " es par");
        }
        else
        {
            Console.WriteLine(num1 + " es impar");
        }
        if (num2 % 2 == 0)
        {
            Console.WriteLine(num2 + " es par");
        }
        else
        {
            Console.WriteLine(num2 + " es impar");
        }
        if (num3 % 2 == 0)
        {
            Console.WriteLine(num3 + " es par");
        }
        else 
        {
            Console.WriteLine(num3 + " es impar");
        }
    }
}