﻿#pragma warning disable
using System;
using System.Security.Cryptography;
public class Estudiante
{
    static int Edad;
    static double NotaAdmision;
    static string Nombre="",Carrera="",Carnet="";
    public static void Main()
    {
        
        Console.WriteLine("Ingrese el nombre del estudiante");
        Nombre=Console.ReadLine().ToString();
        do
        {
            Console.WriteLine("Ingrese la edad del estudiante");
            if (int.TryParse(Console.ReadLine(),out Edad))
            {
                break;
            }
            else if (Edad<15||Edad>80)
            {
                Console.WriteLine("Edad fuera de rango, vuelva a ingresar una edad válida");
            }
            else
            {
                Console.WriteLine("Edad no válida, vuelva a ingresar una edad válida");
            }
        }while(true);
        Console.WriteLine("Ingrese la carrera del estudiante");
        Carrera = Console.ReadLine().ToString();
        Console.WriteLine("Ingrese el carnet del estudiante");
        Carnet=Console.ReadLine().ToString();
        Console.WriteLine("Ingrese la nota de admisión obtenida");
        double.TryParse(Console.ReadLine(), out NotaAdmision);
        Estudiante objetoProgram = new Estudiante();
        Console.Clear(); 
        objetoProgram.showResumen();

    }

    void showResumen() 
    {
        Console.WriteLine($"Nombre del alumno: {Nombre}");
        Console.WriteLine($"Edad del estudiante: {Edad}");
        Console.WriteLine($"Carrera a la que aspira: {Carrera}");
        Console.WriteLine($"Número de carnet: {Carnet}");
        Console.WriteLine($"Nota obtenida en el examen de admisión: {NotaAdmision}");
        puedeMatricular();
    }
    bool notaAdmision(double numero)
    {
        bool matricula;
        if (numero>=75)
        {
           matricula = true; 
        }
        else 
        {
            matricula = false;
        }
        return matricula;
    }
    void puedeMatricular()
    {
        bool terminaCon=Carnet.EndsWith("2025");
        if(notaAdmision(NotaAdmision)==true&&terminaCon==true)
        {
            Console.WriteLine("Todo parece estar bien, ¡Bienvenido a la Universidad Rafael Landivar!");
        }
        else if (notaAdmision(NotaAdmision)==false&&terminaCon==false)
        {
            Console.WriteLine("No puedes matricularte, suerte para la próxima");
        }
        else if (terminaCon==false)
        {
            Console.WriteLine("Error, número de carnet ingresado no válido");
        }
        else if (notaAdmision(NotaAdmision)==false)
        {
            Console.WriteLine("No se puede matricular porque obtuvo una nota de admisión por debajo de lo esperado");
        }
    }
}