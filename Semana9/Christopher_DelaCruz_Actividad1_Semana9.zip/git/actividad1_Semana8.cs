﻿class actividad1_Semana8
{
    static void Main()
    {
        int c = 0;
        Console.WriteLine("Ingrese un número de no mas de 6 números");
        if (int.TryParse(Console.ReadLine(), out int num)|| num < 1 || num > 999999)
        {
            for (int i = 1; i < (num+1); i++)
            {
                if (num%i == 0)
                {
                    c++;
                }
            }
            if (c!=2)
            {
                Console.WriteLine("no es primo");
            }
            else
            {
                Console.WriteLine("es primo");
            }
        }
        else
        {
            Console.WriteLine("No es válido");
        }
    }        
}